// BeanScope 검증용 서버 — 시뮬레이터와 같은 구조를 실제로 갖는 최소 서버 (의존성 없음, Node 22+)
//
//   요청 → [대기 큐 (QUEUE)] → [워커 스레드 세마포어 (THREADS)] → [DB 커넥션 풀 (CONNS)] → 응답
//
// DB 커넥션 풀 = worker_threads 로 띄운 SQLite 커넥션 N개. 각 워커는 자기 DatabaseSync 를 갖고
// 실제로 CPU를 태우는 쿼리(재귀 CTE)를 돌린다. 시작 시 DB_MS 만큼 걸리도록 쿼리 크기를 자동 보정한다.
//
// 실행:  node server.js            (기본: THREADS=50 CONNS=10 QUEUE=100 DB_MS=30 PORT=8080)
//        THREADS=200 CONNS=10 node server.js
//   GET /            → 요청 1건 처리
//   GET /stats       → 현재 상태 (in-flight, 대기, 커넥션 사용)
//   GET /reset       → 카운터 초기화

const http = require('node:http');
const { Worker, isMainThread, parentPort, workerData } = require('node:worker_threads');

const CFG = {
  THREADS: +process.env.THREADS || 50,
  CONNS: +process.env.CONNS || 10,
  QUEUE: +process.env.QUEUE || 100,
  DB_MS: +process.env.DB_MS || 30,
  CPU_MS: +process.env.CPU_MS || 0,   // Node 메인 스레드는 하나라 병렬 CPU 구간을 재현 못함 → 기본 0 (시뮬 스윕도 cpu 0으로 맞춤)
  PORT: +process.env.PORT || 8080,
};

/* ─────────── 워커 = DB 커넥션 1개 ─────────── */
if (!isMainThread) {
  const { DatabaseSync } = require('node:sqlite');
  const db = new DatabaseSync(':memory:');
  const q = db.prepare('WITH RECURSIVE c(x) AS (SELECT 1 UNION ALL SELECT x+1 FROM c WHERE x < ?) SELECT count(*) AS n FROM c');
  parentPort.on('message', ({ id, n }) => {
    const t0 = process.hrtime.bigint();
    q.get(n);                                                     // 실제 SQLite 실행 (CPU 점유)
    parentPort.postMessage({ id, ms: Number(process.hrtime.bigint() - t0) / 1e6 });
  });
  return;
}

/* ─────────── 메인: 큐 → 스레드 → 커넥션 풀 ─────────── */
const pool = [];                 // { w, busy }
const connWaiters = [];          // 커넥션을 기다리는 콜백 (= 시뮬레이터의 waitconn)
const pending = new Map();       // id → resolve
let nextId = 1;
for (let i = 0; i < CFG.CONNS; i++) {
  const w = new Worker(__filename, { workerData: { i } });
  const slot = { w, busy: false };
  w.on('message', ({ id, ms }) => { const res = pending.get(id); pending.delete(id); slot.busy = false; grantConn(); res(ms); });
  pool.push(slot);
}
function grantConn() {
  while (connWaiters.length) { const s = pool.find(p => !p.busy); if (!s) return; s.busy = true; connWaiters.shift()(s); }
}
function acquireConn() { return new Promise(res => { connWaiters.push(res); grantConn(); }); }
function dbQuery(slot, n) { return new Promise(res => { const id = nextId++; pending.set(id, res); slot.w.postMessage({ id, n }); }); }

// DB_MS 보정: 재귀 깊이 n을 이진탐색해서 평균 DB_MS 근처로 맞춘다
let ROWS = 20000;
async function calibrate() {
  const slot = pool[0]; slot.busy = true;
  await dbQuery(slot, 1000);                                     // 워밍업
  let lo = 1000, hi = 5_000_000;
  for (let it = 0; it < 22; it++) {
    const mid = Math.floor((lo + hi) / 2); let sum = 0;
    for (let k = 0; k < 5; k++) sum += await dbQuery(slot, mid);
    (sum / 5 < CFG.DB_MS ? (lo = mid) : (hi = mid));
    if (hi - lo < 200) break;
  }
  ROWS = lo; slot.busy = false;
  let sum = 0; for (let k = 0; k < 10; k++) sum += await dbQuery(slot, ROWS);
  const alone = sum / 10;
  // 전 커넥션 동시 실행 시 — CPU/터보/하이퍼스레딩 경합으로 단독보다 느려진다. 용량은 이 값이 결정한다.
  const t0 = performance.now(); const R = 8;
  await Promise.all(pool.map(p => (async () => { for (let k = 0; k < R; k++) await dbQuery(p, ROWS); })()));
  const together = (performance.now() - t0) / R;
  console.log(`[calibrate] rows=${ROWS}  단독 ${alone.toFixed(1)}ms (목표 ${CFG.DB_MS}ms)  |  ${CFG.CONNS}개 동시 ${together.toFixed(1)}ms → 실질 용량 ≈ ${(CFG.CONNS / together * 1000).toFixed(0)}rps`);
  console.log(`[calibrate] 시뮬레이터에는 DB 처리시간 ${together.toFixed(0)}ms 로 넣어야 포화 구간이 맞는다 (compare.js --db ${together.toFixed(0)})`);
}
// 시뮬레이터처럼 지수분포 서비스 시간: 평균 ROWS, exp 샘플
const expo = (mean) => -Math.log(1 - Math.random()) * mean;

// 스레드 세마포어 + 대기 큐
let inThreads = 0; const queue = [];
const stats = { total: 0, done: 0, rejected: 0, queueMax: 0, waitConnMax: 0 };
function acquireThread() {
  return new Promise((res, rej) => {
    if (inThreads < CFG.THREADS) { inThreads++; return res(); }
    if (queue.length >= CFG.QUEUE) return rej(new Error('queue full'));
    queue.push(res); stats.queueMax = Math.max(stats.queueMax, queue.length);
  });
}
function releaseThread() { if (queue.length) queue.shift()(); else inThreads--; }
function busyCpu(ms) { const end = performance.now() + ms; while (performance.now() < end) { /* spin */ } }

const server = http.createServer(async (req, res) => {
  if (req.url === '/stats') return res.end(JSON.stringify({ cfg: CFG, inThreads, queued: queue.length, waitConn: connWaiters.length, connBusy: pool.filter(p => p.busy).length, ...stats }));
  if (req.url === '/reset') { Object.assign(stats, { total: 0, done: 0, rejected: 0, queueMax: 0, waitConnMax: 0 }); return res.end('ok'); }
  stats.total++;
  try { await acquireThread(); } catch { stats.rejected++; res.statusCode = 503; return res.end('queue full'); }
  try {
    stats.waitConnMax = Math.max(stats.waitConnMax, connWaiters.length + 1);
    const slot = await acquireConn();                             // ← waitconn 구간
    const dbMs = await dbQuery(slot, Math.max(500, Math.round(expo(ROWS))));   // ← db 구간
    if (CFG.CPU_MS) busyCpu(CFG.CPU_MS);                          // ← cpu 구간 (옵션. 이벤트 루프를 점유하므로 낮은 rps에서만 의미 있음)
    stats.done++;
    res.setHeader('content-type', 'application/json'); res.end(JSON.stringify({ ok: true, dbMs: +dbMs.toFixed(2) }));
  } finally { releaseThread(); }
});
server.keepAliveTimeout = 30000; server.maxConnections = 10000;

calibrate().then(() => server.listen(CFG.PORT, () => console.log(`[server] http://localhost:${CFG.PORT}  threads=${CFG.THREADS} conns=${CFG.CONNS} queue=${CFG.QUEUE} db=${CFG.DB_MS}ms cpu=${CFG.CPU_MS}ms`)));
