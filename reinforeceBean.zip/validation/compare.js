// 실측 CSV(load.js 출력)와 시뮬레이터(index.html의 엔진)를 같은 rps로 비교 — 터미널용. UI의 「실측 검증」 탭과 같은 계산.
//
// 실행:  node compare.js result.csv [--db 30] [--threads 50] [--conns 10] [--queue 100] [--timeout 3000]
//   --db 를 바꿔가며 돌리면 "어떤 DB 처리시간으로 보정해야 실측과 맞는지"를 찾을 수 있다 (캘리브레이션).

const fs = require('node:fs'), path = require('node:path');
const arg = (k, d) => { const i = process.argv.indexOf('--' + k); return i > 0 ? +process.argv[i + 1] : d; };
const csv = process.argv[2] || 'result.csv';
const cfg = { threads: arg('threads', 50), conns: arg('conns', 10), dbTimeMs: arg('db', 30), queueCap: arg('queue', 100), timeoutMs: arg('timeout', 3000), cpuTimeMs: arg('cpu', 0), retryProb: 0 };

// index.html에서 엔진 구획(1~4)만 추출해 로드 (렌더링/DOM 이전까지)
const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
const src = html.match(/<script>([\s\S]*)<\/script>/)[1];
const engine = src.split(/\/\* =+\r?\n \* 5\./)[0];
const E = new Function(engine + '\nreturn { runHeadless };')();

const rows = fs.readFileSync(csv, 'utf8').trim().split(/\r?\n/).slice(1).map(l => l.split(',').map(Number)).filter(r => r.length >= 4);
console.log(`시뮬 설정: threads=${cfg.threads} conns=${cfg.conns} db=${cfg.dbTimeMs}ms queue=${cfg.queueCap} timeout=${cfg.timeoutMs}ms`);
console.log(' rps | 실측 p95 | 시뮬 p95 | 실측 실패 | 시뮬 실패');
let se = 0, n = 0;
for (const [rps, , p95, err] of rows) {
  const r = E.runHeadless(Object.assign({ rps }, cfg), 15, 5);
  console.log(String(rps).padStart(4), '|', p95.toFixed(0).padStart(7), '|', r.p95.toFixed(0).padStart(7), '|', ((err * 100).toFixed(1) + '%').padStart(8), '|', ((r.errRate * 100).toFixed(1) + '%').padStart(8));
  if (p95 > 0) { se += Math.abs(r.p95 - p95) / p95; n++; }
}
console.log(`p95 평균 상대오차: ${(se / n * 100).toFixed(0)}%`);
